# Copyright 2022 Cerebras Systems.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .english_fasttext_filter import EnglishFastTextFilter
from .id_dedup_filter import IDDedupFilter
from .inclusive_latex_symbol_filter import InclusiveLatexSymbolFilter
from .latex_symbol_filter import LatexSymbolFilter
from .math_fasttext_filter import MathFastTextFilter
from .pypi_package_filter import PyPIPackageFilter
from .python_filters import (
    PythonLanguageCharacterFilter,
    PythonPylintScoreFilter,
    PythonSyntaxFilter,
)
from .stack_v2_python_filter import StackV2_SmolIds_PythonFilter
from .text_quality_fasttext_filter import FastTextQualityFilter
from .url_filter import CustomURLFilterWithWhitelist

__all__ = [
    "EnglishFastTextFilter",
    "LatexSymbolFilter",
    "MathFastTextFilter",
    "FastTextQualityFilter",
    "InclusiveLatexSymbolFilter",
    "CustomURLFilterWithWhitelist",
    "PythonSyntaxFilter",
    "PythonPylintScoreFilter",
    "PythonLanguageCharacterFilter",
    "PyPIPackageFilter",
    "IDDedupFilter",
    "StackV2_SmolIds_PythonFilter",
    "StackV2_SmolIds_PythonFilter",
    "PyPIPackageFilter",
    "IDDedupFilter",
]
